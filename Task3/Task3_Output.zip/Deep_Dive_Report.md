
# Task 3: Sales Performance Deep-Dive

## Objective
Analyze sales performance and identify patterns in products,
categories, cities, customers, and monthly sales.

## Key Performance Indicators
- Total Sales: 139,399,439.65
- Total Orders: 992
- Unique Customers: 947
- Average Order Value: 140,523.63

## Key Findings
- Highest-sales category: Electronics
- Top product among the top 10: Shoes
- Highest-sales city among the top 10: Patna
- Highest-sales month: 2025-03

## Business Recommendations
- Review the best-performing categories and products to understand
  what contributes to sales.
- Investigate lower-performing categories and cities for improvement.
- Track monthly sales to identify trends and plan inventory.
- Use customer spending and order frequency to understand purchasing patterns.

## Note
These findings describe the observed dataset and do not establish
the causes of sales performance.
